# WorkBuddy 自动领取

在 Windows 后台按计划领取 WorkBuddy 积分的本地工具。它复用已经登录的 WorkBuddy 会话，通过个人中心读取“积分余额”并核验结果；不会保存账号密码，也不会上传截图或 OCR 文字。

## 它会做什么

- 默认每天 `00:00` 尝试领取一次；时间可在 `config.json` 的 `ClaimTime` 中修改。
- 电脑锁屏、睡眠或桌面暂不可操作时，每 `60` 秒等待一次，且不计入领取次数；解锁后当天最多尝试 `5` 次。
- 成功、确认“今日已领取”或达到当天失败上限后，守护进程休眠到下一天，不会全天轮询或反复点击。
- WorkBuddy 未运行时会后台启动；由工具启动的 WorkBuddy 会在流程结束后关闭。开始领取时只要 WorkBuddy 窗口可见且未最小化，结束后就保持展开，不依赖当时键盘焦点；只有原本已最小化的窗口才恢复为最小化。
- 成功、今日已领取、失败都会发送 Windows 通知中心通知，并保留三天。
- 守护进程常驻在右下角通知区域：左键图标打开面板，右键可以打开面板、重试领取或退出守护。
- 右键菜单中的“开机启动”带勾选状态；取消勾选只关闭下次登录自启，当前守护不会退出。

## 守护面板

面板会自动适配 Windows 的浅色/深色模式，并分为“概览”和“设置”：

- “概览”显示最近领取状态、当前余额、更新时间、领取详情和下一次自动领取时间。
- “重试领取”按照“手动尝试次数”执行；运行期间按钮会锁定，避免重复提交。
- “设置”可修改 WorkBuddy 路径、领取时间、自动/手动尝试次数、失败间隔以及两个界面等待时间。
- 点击“保存并立即应用”会唤醒守护并重新计算计划，不需要重启程序。
- 关闭面板只会隐藏到右下角；要停止常驻守护，请右键托盘图标并选择“退出守护”。
- “打开高级配置”可编辑 OCR 与界面适配参数，面板保存常用设置时会保留这些高级参数。

## 领取与核验逻辑

每次尝试严格按以下顺序执行：

1. 最多点击左下角个人中心三次；每次点击后，以“积分余额”、同行明确数字和至少一项个人菜单文字共同确认面板已经打开。
2. 识别“积分余额”与数字之间的刷新图标并点击；只有同一个明确数字连续两帧一致，才记录为领取前余额。
3. 每次成功读取并确认积分余额后，立即扫描整个窗口，依次检查精确的“立即领取”、连续两帧的“今日已领/已领取”、以及“签到领积分/去签到/签到”。
4. 如果三类文字都没有、也没有点击过签到入口，则直接精确定位并点击同一面板中的“Buddy加油站”，等待页面加载后继续按相同优先级扫描。此快速路径避免重复关闭面板、重复刷新余额和重复 OCR。
5. 只有“Buddy加油站”快速路径不可用或页面没有出现可确认动作时，才执行兼容后备：关闭个人中心并再次整窗扫描，随后重新打开个人中心、确认余额、再次扫描，再进入 Buddy 加油站。
6. 点击签到入口后等待“立即领取”；没有出现最终按钮时继续后续兜底路径，签到入口本身不算领取成功。
7. “立即领取”不依赖卡片、锚点、裁剪区域或固定位置。它使用整窗直读、整窗放大、灰度增强和反色四路 OCR；只在清除空格与标点后仍完整、精确等于四个字“立即领取”时点击，任何近似误读都不会触发最终领取。
8. 点击“立即领取”后重新打开个人中心、点击刷新并连续两帧确认余额：余额增加才判定为领取成功；余额不变且连续看到已领取状态才判定为“今日已领取”；其余情况均失败。

按钮与余额均由 OCR 动态识别，不依赖固定领取按钮坐标、Buddy 加油站期数或界面颜色。因此 WorkBuddy 的浅色/深色模式和普通布局变化都有适配空间。

## 通知内容

通知正文将状态与余额放在同一行，避免 Windows 通知中心折叠后遗漏余额：

- `领取成功 · 积分余额：领取前 → 领取后`
- `今日已领取 · 当前余额：余额`
- `领取失败 · 最后读取余额：余额`

如果 Windows 禁止应用通知，工具会写入日志并退回为临时托盘气泡；请在 Windows 设置中允许 WorkBuddy Auto Claim 通知。

## 安装与启动

### 前提

- Windows 10 版本 19041 或更高。
- 已安装并登录 WorkBuddy。
- 已安装 .NET 8 Desktop Runtime（如果双击程序没有任何反应，先安装它）。

### 首次安装

1. 打开 PowerShell，进入项目目录并构建：

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
   ```

2. 双击 `install.cmd`，或运行：

   ```powershell
   .\install.cmd
   ```

这会为当前用户创建开机自启任务，并启动后台守护。首次运行会在 `release\` 内从 `config.example.json` 创建 `config.json`。

要删除开机自启任务，双击 `uninstall.cmd`。它不会强制结束已经运行的守护进程；当前进程会在退出登录或下次重启后停止。

## 配置

推荐从右下角托盘图标打开“设置”修改；保存后立即生效。也可以直接编辑 `release\config.json`，守护会在下一次唤醒时重新读取。

常用项如下：

| 配置项 | 默认值 | 说明 |
| --- | --- | --- |
| `WorkBuddyPath` | `D:\Program Files\WorkBuddy\WorkBuddy.exe` | WorkBuddy 程序路径 |
| `ClaimTime` | `00:00` | 每日领取时间，格式 `HH:mm` |
| `RetryIntervalSeconds` | `60` | 守护发生一般异常后的再次检查间隔；锁屏等待固定为 60 秒 |
| `MaxAttempts` | `5` | 每日自动领取的最多尝试次数，硬上限为 5 |
| `ManualMaxAttempts` | `1` | 面板或 `--manual-test` 手动领取的最多尝试次数 |
| `LaunchWaitSeconds` | `20` | 启动 WorkBuddy 后的等待秒数 |
| `CardReadyTimeoutSeconds` | `30` | 等待个人中心余额区域加载的最长秒数 |
| `ImmediateClaimKeywords` | `立即领取` | 最终领取按钮的识别文字 |
| `CheckInKeywords` | `签到领积分`、`去签到`、`签到` | 进入领取流程的入口文字 |

其余 `Balance*`、`VisualBalance*`、`Profile*` 配置用于 OCR 兼容和截图校准。正常使用无需修改；只有 WorkBuddy 大版本改版、日志和诊断截图显示定位失败时才调整。

## 测试与常用命令

所有命令均从 `release\` 目录运行：

```powershell
cd .\release

# 运行内置回归检查；不会领取
.\WorkBuddyAutoClaim.exe --self-test

# 验证托盘图标和 GUI 能创建；不会启动或控制 WorkBuddy
.\WorkBuddyAutoClaim.exe --ui-smoke-test

# 读取当前余额并发送一条真实 Windows 通知；不会点击签到或领取
.\WorkBuddyAutoClaim.exe --test-notification

# 打开个人中心、验证“积分余额”并保存截图；不会领取
.\WorkBuddyAutoClaim.exe --test-personal-center

# 验证快速路径耗时：读取余额并进入 Buddy 加油站，只识别状态，不点击领取或签到
.\WorkBuddyAutoClaim.exe --test-fast-route

# 对已有截图检查余额和领取文字；不会控制 WorkBuddy
.\WorkBuddyAutoClaim.exe --verify-claim-ocr "C:\path\to\screenshot.png"

# 单独验证整窗“立即领取”精确四字 OCR；不会控制 WorkBuddy
.\WorkBuddyAutoClaim.exe --verify-immediate-ocr "C:\path\to\screenshot.png"

# 验证个人中心组合锚点、余额和刷新图标；不会控制 WorkBuddy
.\WorkBuddyAutoClaim.exe --verify-personal-center-ocr "C:\path\to\screenshot.png" "2258.6"
```

以下命令会执行一次真实领取流程，适合在需要人工验证时使用：

```powershell
.\WorkBuddyAutoClaim.exe --manual-test
```

手动测试按 `ManualMaxAttempts` 执行（默认一次），不会写入当天的自动领取成功状态；失败后会停止并等待处理，后台守护随后恢复。

## 日志与排错

工具的运行数据都在：

```text
%LOCALAPPDATA%\WorkBuddyAutoClaim\
```

重点文件：

- `workbuddy-auto-claim.log`：运行、OCR、通知与失败原因。
- `state.json`：当天自动领取的成功或终止失败状态。
- `run-status.json`：守护面板显示的最近领取状态、余额和尝试次数。
- `workbuddy-*.png`：领取前后、个人中心识别失败等诊断截图。
- `workbuddy-personal-center-ocr-failure.txt`：识别失败时保存的 OCR 原文。

常见检查顺序：

1. 运行 `--test-notification`，确认通知中心能看到“当前余额”。
2. 运行 `--test-personal-center`，确认个人中心截图中可见“积分余额”。
3. 若每日未运行，检查 `workbuddy-auto-claim.log` 中是否有“桌面已锁定”“未发现积分余额”或“通知中心 Toast 被 Windows 阻止”。
4. 发生界面改版时，保留对应诊断截图和日志，再调整 OCR 配置或更新工具。

## 稳定性与恢复

- Windows OCR 的执行预算为 8 秒；超时后立即终止子进程，并最多再等待 2 秒确认进程退出。本次会归类为“OCR 超时”并安全失败，不会盲点。
- “立即领取”和“签到/签到领积分”均先按完整窗口 OCR 识别；直读漏字时会放大整张窗口重读，不依赖卡片、裁剪区域或固定坐标。“立即领取”还会尝试整窗原图、灰度和反色 OCR。
- 积分数字会在 OCR 定位到的余额同行中避开刷新图标后单独放大，并要求至少两种图像处理结果一致，防止 `2,132.34` 被误读成 `13234`。Buddy 入口兼容本机 Windows OCR 已观察到的 `8uddy加油站` 首字母误读。
- 点击“签到”或“立即领取”后，工具必须观察到界面真实变化；明确数字余额增加才会报告领取成功，余额不变时还必须在变化后的界面中连续确认“今日已领”或“已领取”，余额下降则安全失败。
- 在领取前、打开个人中心、签到入口后和领取结果核验期间，只要检测到“登录失效”“请登录”或“重新登录”，就通知你手动登录并停止当天后续尝试。
- `state.json` 使用原子写入和 `.bak` 备份。两份状态都损坏时，当天安全停止并通知，不会重复领取。
- 安装的 Windows 任务在登录时启动守护进程；守护异常退出时，任务计划会每分钟最多重启 3 次。
- 安装、手动测试或安全测试结束时，工具优先请求任务计划恢复守护；只有新守护完成配置加载并主动发出就绪信号后才记录恢复成功，直接启动回退也执行同样确认。
- `build.ps1` 同时生成 `artifacts\WorkBuddyAutoClaim-v1.1.1.zip`；包内不包含本机 `config.json`、PDB、状态或诊断数据。
- `%LOCALAPPDATA%\WorkBuddyAutoClaim\workbuddy-auto-claim.log` 只保留最近 30 天；`diagnostics\` 仅保留最新 20 份失败诊断。诊断包包含截图、OCR 原文、WorkBuddy 版本、窗口尺寸和 DPI；成功领取不会保留领取截图。

失败通知除余额外，还会包含失败阶段、已执行尝试次数，以及 WorkBuddy 是保留原前台、保留后台最小化，还是由工具启动后关闭。

## 项目关系

本项目是独立仓库实现，不是 `GitOfUser/workbuddy-checkin` 的 Fork，也不共享提交历史。早期仅参考了其流程思路；本工具的后台行为、OCR 校验、通知和维护均独立实现。
